BLUNDERDOME PLAYER PATCH - DRAG AND DROP - 2026-10-27

Requires a supported Rain of Fear 2 (RoF2) EverQuest client. This is a patch, not the full game.

1. Fully close EverQuest. Use a separate RoF2 game folder for BLUNDERDOME.
2. Extract this ZIP. Copy ALL its contents into the game folder containing eqgame.exe.
3. Merge Resources and uifiles folders and choose Replace files when prompted.
   Do not leave the patch inside an extra subfolder.
4. No installer, BAT, PowerShell or separate port update is needed.
5. Use the Default UI. Launch eqgame.exe with the argument patchme through a shortcut:
   Example shortcut Target: "C:\Games\BLUNDERDOME\eqgame.exe" patchme
   Start in: C:\Games\BLUNDERDOME
6. Log in with your public EQEmu account and select CSHOME ALONE : PvPresents Blunderdome.

The correct VPS port9000 executable, dual-class/loot adapters, public eqhost,
spell files, Default UI, old CSHOME assets and Guide Djeph model loading are included.
Do not apply the old patch afterward: it can restore the old port19001 executable.
Do not run the official EverQuest patcher.

GlobalLoad.txt is supplied directly under Resources, including the Djeph model entry;
no script edits it. This replaces that file with the supplied RoF2 model list.
Other servers' custom model-list additions are not retained, so use a separate client.
If Windows refuses to replace an existing read-only file, open that file's Properties,
clear Read-only and retry. A manual copy still requires permission to write the destination.

This ZIP contains only player patch files and this README. No server configuration,
passwords, SQL database or installer scripts. No full-client/in-game test was performed
as part of this repackaging; files are based on the existing working player payload.
